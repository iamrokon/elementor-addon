<?php
class PPM_PromoBoxes_Widget extends \Elementor\Widget_Base {

	public function get_name() {
		return 'gff-promo-boxes';
	}

	public function get_title() {
		return esc_html__( 'Promo Boxes', 'ppm-quickstart' );
	}

	public function get_icon() {
		return 'fa fa-code';
	}

	public function get_categories() {
		return [ 'general' ];
	}

	protected function register_controls() {

		// Content Tab Start

		$this->start_controls_section(
			'content-section',
			[
				'label' => esc_html__( 'Settings', 'plugin-name' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		// Elementor complex addon development start

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'title',
			[
				'label' => esc_html__( 'Title', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Sildenafil' , 'textdomain' ),
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'sub_title',
			[
				'label' => esc_html__( 'Sub title', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Erectile Dysfunction' , 'textdomain' ),
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'photo',
			[
				'label' => esc_html__( 'Photo', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'btn_text_1',
			[
				'label' => esc_html__( 'Button Text 1', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Start Visit' , 'textdomain' ),
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'btn_link_1',
			[
				'label' => esc_html__( 'Button Link 1', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::URL,
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'btn_text_2',
			[
				'label' => esc_html__( 'Button Text 2', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Start Visit' , 'textdomain' ),
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'btn_link_2',
			[
				'label' => esc_html__( 'Button Link 2', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::URL,
				'label_block' => true,
			]
		);






		$this->add_control(
			'list',
			[
				'label' => esc_html__( 'Repeater List', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'list_title' => esc_html__( 'Title #1', 'textdomain' ),
						'list_content' => esc_html__( 'Item content. Click the edit button to change this text.', 'textdomain' ),
					],
					[
						'list_title' => esc_html__( 'Title #2', 'textdomain' ),
						'list_content' => esc_html__( 'Item content. Click the edit button to change this text.', 'textdomain' ),
					],
				],
				'title_field' => '{{{ list_title }}}',
			]
		);

		// Elementor complex addon development end

		$this->add_control(
			'title',
			[
				'label' => esc_html__( 'Title', 'elementor-addon' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Rokon', 'elementor-addon' ),
			]
		);

		$this->add_control(
			'designation',
			[
				'label' => esc_html__( 'Designation', 'elementor-addon' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Web developer', 'elementor-addon' ),
			]
		);

		$this->add_control(
			'photo',
			[
				'label' => esc_html__( 'Photo', 'elementor-addon' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
			]
		);

		$this->add_control(
			'social_links',
			[
				'label' => esc_html__( 'Social Link', 'elementor-addon' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => [
					[
						'name' => 'icon',
						'label' => esc_html__( 'Icon', 'elementor-addon' ),
						'type' => \Elementor\Controls_Manager::ICONS,
					],
					[
						'name' => 'link',
						'label' => esc_html__( 'Link', 'elementor-addon' ),
						'type' => \Elementor\Controls_Manager::URL,
						'placeholder' => 'https://example.com',
					],
				],
				'default' => [
					[
						'icon' => 'fa fa-facebook', // Default icon class
						'link' => [ 'url' => 'https://facebook.com' ], // Default link
					],
				],
			]
		);
		

		$this->add_control(
			'style',
			[
				'label' => esc_html__( 'Style', 'elementor-addon' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'style1',
				'options' => [
					'style1' => esc_html__( 'Style 1', 'elementor-addon' ),
					'style2' => esc_html__( 'Style 2', 'elementor-addon' ),
				],
			]
		);

		$this->end_controls_section();

		// Content Tab End

	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		?>
		<div class="rasel-team-member">
			<?php if(array_key_exists('photo',$settings) && !empty($settings['photo'])){?>
			<div class="rasel-team-member-photo">
				<?php echo wp_get_attachment_image( $settings['photo']['id'], 'large'); ?>
			</div>
			<?php } ?>
			<div class="rasel-team-member-info">
				<h3><?php echo $settings['title']; ?></h3>
				<?php if(array_key_exists('designation',$settings) && !empty($settings['designation'])){?>
				<p> <?php echo $settings['designation']; ?> </p>
				<?php } ?>

				<div class="social-links">
					<?php 
					foreach($settings['social_links'] as $link): 
						$is_external = $link['link']['is_external'] == 'on' ? '_blank' : '';
					?>
					<a href="<?php echo $link['link']['url'];?>" target="<?php echo $is_external;?>">
					<i class="<?php echo $link['icon']['value'];?>"></i>
					</a>
					<?php endforeach;?>
				</div>

			</div>
		</div>

		<?php
	}
}